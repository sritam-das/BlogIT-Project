$(document).ready(function () {

  //hide register and login link from nav bar 
  if(localStorage.getItem("EMAILID") != null){
    $("#regsterLink").hide();
    $("#loginLink").hide();
  }
  //modal close button
  $('#mod_cls').on('click',function(){
    // console.log("1");
    //clear form input 
    $('#loginForm').trigger("reset");
    $('#regiserForm').trigger("reset");
  });

  // start of register button
  $('#registerBtn').click(function (event) {
    event.preventDefault();
    // console.log("1");debugger;
    var fullname = $('#fname').val();
    // var lastname = $('#lname').val();
    var email1 = $('#email').val();
    var pass = $('#password').val();
    var confirmpassword = $('#cpassword').val();
    // console.log("2")
    // console.log(firsrname);
    // console.log(lastname);
    // console.log(email1);
    // console.log(pass);
    // console.log(confirmpassword);

if(fullname == "" || email1 == "" || pass == ""){
  alert("Please fill required details");
}
else{
  
  if (!(pass === confirmpassword)) {
    $('#cpassword').val("");
    $('#password').val("");
    alert("Password not matched")
  }
  else {
    var jsonData = { fname: fullname, email: email1, password: pass };
    // console.log("obj"+jsonData);
    $.ajax({
      type: "POST",
      url: "http://localhost:3000/register",
      data: jsonData,
      // async: true,
      success: function (data) {
        // console.log("success..");
        // console.log(data);
        $('#fname').val("");
        $('#email').val("");
        $('#cpassword').val("");
        $('#password').val("");
        alert("Registered successfully");
        // $('#RegisterModal').modal('hide');
      },
      error: function () {
        // console.log("not able to process request");
        $('#fname').val("");
        $('#email').val("");
        $('#cpassword').val("");
        $('#password').val("");
        alert("Something went wrong.Try again...")
      },
    });
  }
}
  });
  // end of register here

  // start of login button
  $('#loginBtn').click(function(event){

    event.preventDefault();
    var emailId = $('#email1').val();
    var pass = $('#pwd').val();
    // console.log(emailId);
    // console.log(pass);
    if(emailId == "" ||  pass == ""){
      alert("Please fill required details");
    }
    else{
    $.ajax({
      type: "GET",
      url: "http://localhost:3000/register",
      success: function (data) {
        // console.log(data);
        var flag = false;
        $.each(data, function (i, v) {
          // console.log(v.email);
          // console.log(v.password);
          if(emailId == v.email && pass == v.password){
            // console.log("match");
            flag = true;
            return flag;
          }
        });
        // console.log(flag);
        if(flag){
          localStorage.setItem("EMAILID",emailId);
          $('#email1').val("");
          $('#pwd').val("");
          //if successfull login then hide register login from nav bar
          alert("Login successfully !!!");
          // $('#LoginModal').modal('hide');
          window.location.href = "http://127.0.0.1:5500/index.html";
          // console.log("after login")
          // $('#loginLink').hide();
          // $('#regsterLink').hide(); 
        }
        else{
          $('#email1').val("");
          $('#pwd').val("");
          alert("Incorrect credentials !!!"); 
        }
      },
      error: function () {
        // console.log("not able to process request");
        $('#email1').val("");
        $('#password').val("");
        alert("Something went wrong.Try again...")
      },
    });
  }
  });
  // end of login

  //start of create blog
  $("#createBlog").click(function(){
    
    console.log(localStorage.getItem("EMAILID"));

    if(localStorage.getItem("EMAILID") == null){
      alert("You have not logged in please login first...");
      //open login modal
      console.log("login modal open");
      // jQuery.noConflict(); 
      // $('#LoginModal').modal('show'); 
    }
    else{
      console.log("in else")
      window.location.href = "http://127.0.0.1:5500/ui/home.html";
    }
  });
  //end of create blog


  $("#homebtn").click(function(){
    // console.log("crete blog")
    // console.log(document.getElementById("getval"));
    document.getElementById("getval").innerHTML=localStorage.getItem("EMAILID");
  });
  $("#logout").click(function(){
    console.log("in logout");
    console.log(localStorage.getItem("EMAILID"));
    localStorage.setItem("EMAILID","");
    localStorage.removeItem("EMAILID");
    console.log(localStorage.getItem("EMAILID"));
    document.getElementById("getval").innerHTML=localStorage.getItem("EMAILID");
    window.location.href = "http://127.0.0.1:5500/index.html";
  });
});
